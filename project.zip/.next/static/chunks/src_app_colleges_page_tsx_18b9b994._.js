(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c55d9888._.js",
  "static/chunks/node_modules_9e826329._.js"
],
    source: "dynamic"
});
