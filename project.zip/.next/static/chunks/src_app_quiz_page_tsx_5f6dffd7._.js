(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_44bf6402._.js",
  "static/chunks/src_0fe2f90e._.js"
],
    source: "dynamic"
});
