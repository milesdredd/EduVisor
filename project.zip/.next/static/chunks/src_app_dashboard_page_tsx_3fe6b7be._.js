(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_eaada3ea._.js",
  "static/chunks/node_modules_10c1a008._.js"
],
    source: "dynamic"
});
