(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_5e99f6ca._.js",
  "static/chunks/src_a7411ebf._.js"
],
    source: "dynamic"
});
