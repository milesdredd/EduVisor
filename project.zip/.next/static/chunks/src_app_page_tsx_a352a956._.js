(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_8f6424d2._.js",
  "static/chunks/src_584e9f9e._.js"
],
    source: "dynamic"
});
