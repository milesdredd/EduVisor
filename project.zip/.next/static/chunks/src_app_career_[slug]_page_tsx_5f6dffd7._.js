(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_21118822._.js",
  "static/chunks/node_modules_48d729f7._.js"
],
    source: "dynamic"
});
