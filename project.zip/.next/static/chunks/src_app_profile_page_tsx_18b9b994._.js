(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_24b2e38d._.js",
  "static/chunks/node_modules_d0ddca4e._.js"
],
    source: "dynamic"
});
