(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_f35aa56d._.js",
  "static/chunks/src_55d6f6a4._.js"
],
    source: "dynamic"
});
