(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c55d9888._.js",
  "static/chunks/node_modules_45a239e1._.js"
],
    source: "dynamic"
});
