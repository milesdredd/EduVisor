(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_cc905463._.js",
  "static/chunks/node_modules_603452e3._.js"
],
    source: "dynamic"
});
