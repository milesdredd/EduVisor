(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_7c0efbdf._.js",
  "static/chunks/src_77b85d72._.js"
],
    source: "dynamic"
});
